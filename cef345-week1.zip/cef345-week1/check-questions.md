# CEF 345 Assignment 2: check questions, Weeks 5 and 6

## Week 5: Preliminary design

**1. What is the difference between preliminary and detailed design?**
Preliminary design splits the system into its main parts and fixes the interfaces between them: the architecture, the data model (ERD) and the API. Detailed design works out the inside of each part: which classes and functions exist, the order they call each other, what happens on each error path, and what the screens look like. A good test of preliminary design: each part could go to a different developer who works without talking to the others.

**2. Why is microservices a poor choice for a 5-person student project?**
Every service needs its own deployment, its own database and network calls to the others. That overhead would take more time than the features themselves. Spreading the data across databases also makes an all-or-nothing operation such as "save the sale and reduce the stock" hard, because one database transaction can no longer cover it. Microservices pay off when many teams need to deploy independently, and we are one small team. A layered monolith gives the same separation of responsibilities with one program and one deployment.

**3. In which layer does "a sale cannot exceed stock" belong, and why not in the route?**
In the services layer (`SaleService`), because it is a business rule. A route only maps a URL and method to a controller function. If the rule lived in the route, it would be tied to HTTP and could not be unit-tested without starting a web server. It would also have to be copied into any other way of recording a sale. In the service, the rule has exactly one home and its test calls the function directly.

**4. A student stores a sale with columns `item1`, `qty1`, `item2`, `qty2`. Which normal form does this break, and how do you fix it?**
It breaks first normal form (1NF): it is a repeating group, and it fails the day someone buys more products than there are columns. The fix is a separate `sale_items` table with one row per product in the sale (`sale_id` → `sales`, `product_id` → `products`, `quantity`, `unit_price`, `unit_cost`), giving a one-to-many relationship from `sales` to `sale_items`.

**5. Which status code should `POST /api/sales` return when stock is too low: 400, 404, 409 or 500?**
409 Conflict. The request is well formed, so it is not 400. The product exists, so it is not 404. Nothing broke on the server, so it is not 500. The request clashes with the current state of the data (the stock on hand), and the same request would succeed after a restock. That is exactly what 409 means.

## Week 6: Detailed design

**1. When should you use composition rather than plain association? Give an example.**
Use composition when the part cannot exist without the whole and is deleted with it: `Sale ◆── 1..* SaleItem`. A sale item means nothing without its sale, so deleting the sale deletes its items (`ON DELETE CASCADE` in `schema.sql`). Use a plain association when both objects exist on their own: `Customer 1 ── 0..* Sale`. The customer still exists if a sale is removed.

**2. In "Record a sale", why are all stock checks done before any insert?**
So that if any item is short, the error is raised before anything has been written. The sale either passes every check and is then written completely, or it is refused and the database is untouched. Checking first also keeps the transaction short and gives the assistant the stock error straight away.

**3. What goes wrong if `recordSale` runs without a transaction and the server crashes halfway?**
The database is left half-updated. For example, rice's stock has gone down but the sale was never saved, or the sale is saved without all its items, or a credit customer's balance went up for a sale that does not exist. Stock, sales and debts then disagree permanently, and nothing records why. With a transaction, either all of these changes happen or none do.

**4. Give one example of high coupling and explain how to reduce it.**
The sales page reads `sale_items` column names straight from the database. Renaming a column then breaks the front end, even though the business did not change. To reduce the coupling, the page only knows the JSON shape the API returns, and the repository is the only code that knows table and column names. A change to the database then touches one repository and nothing else.

**5. What does a state diagram give the tester?**
The list of states an object can be in and the transitions between them, which is the list of cases to test. For a MarketStock product the states are In stock, Low and Out, so the tester checks each state and each transition: a sale that takes a product from In stock to Low, one that takes it from Low to Out, and a restock that brings it back. It also shows the boundary values: quantity equal to `min_quantity` is Low, and quantity 0 is Out.
