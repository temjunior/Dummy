-- MarketStock database schema (SQLite, used through node:sqlite)
-- Week 5 in-class practical: the required tables are sales and sale_items.
-- The other five tables are included so that every FOREIGN KEY points at a real table
-- and the whole file runs on an empty database.
-- Money is stored as whole XAF in INTEGER columns (never REAL).

PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  name          TEXT    NOT NULL,
  phone         TEXT    NOT NULL UNIQUE,
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL CHECK (role IN ('owner', 'assistant'))
);

CREATE TABLE products (
  id           INTEGER PRIMARY KEY,
  name         TEXT    NOT NULL UNIQUE,
  unit         TEXT    NOT NULL CHECK (unit IN ('bag', 'cup', 'carton', 'litre', 'piece')),
  buy_price    INTEGER NOT NULL CHECK (buy_price >= 0),
  sell_price   INTEGER NOT NULL CHECK (sell_price >= 0),
  quantity     INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  min_quantity INTEGER NOT NULL DEFAULT 0 CHECK (min_quantity >= 0)
);

CREATE TABLE customers (
  id      INTEGER PRIMARY KEY,
  name    TEXT    NOT NULL,
  phone   TEXT    NOT NULL UNIQUE,
  balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0)
);

-- One row per sale.
CREATE TABLE sales (
  id             INTEGER PRIMARY KEY,
  user_id        INTEGER NOT NULL,
  customer_id    INTEGER,                      -- empty unless the sale is on credit
  payment_method TEXT    NOT NULL
                 CHECK (payment_method IN ('cash', 'mtn_momo', 'orange_money', 'credit')),
  total          INTEGER NOT NULL CHECK (total >= 0),
  created_at     TEXT    NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id)     REFERENCES users (id),
  FOREIGN KEY (customer_id) REFERENCES customers (id),
  -- business rule: a credit sale needs a customer
  CHECK (payment_method <> 'credit' OR customer_id IS NOT NULL)
);

-- One row per product in a sale.
-- unit_price and unit_cost are copied from products at the time of sale, so a later
-- price change does not rewrite old sales and old profit.
CREATE TABLE sale_items (
  id         INTEGER PRIMARY KEY,
  sale_id    INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity   INTEGER NOT NULL CHECK (quantity > 0),
  unit_price INTEGER NOT NULL CHECK (unit_price >= 0),
  unit_cost  INTEGER NOT NULL CHECK (unit_cost >= 0),
  FOREIGN KEY (sale_id)    REFERENCES sales (id) ON DELETE CASCADE,  -- items cannot exist without their sale
  FOREIGN KEY (product_id) REFERENCES products (id)
);

CREATE TABLE restocks (
  id         INTEGER PRIMARY KEY,
  product_id INTEGER NOT NULL,
  quantity   INTEGER NOT NULL CHECK (quantity > 0),
  unit_cost  INTEGER NOT NULL CHECK (unit_cost >= 0),
  supplier   TEXT,
  user_id    INTEGER NOT NULL,
  created_at TEXT    NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (product_id) REFERENCES products (id),
  FOREIGN KEY (user_id)    REFERENCES users (id)
);

CREATE TABLE repayments (
  id          INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL,
  amount      INTEGER NOT NULL CHECK (amount > 0),
  user_id     INTEGER NOT NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (customer_id) REFERENCES customers (id),
  FOREIGN KEY (user_id)     REFERENCES users (id)
);

CREATE INDEX idx_sale_items_sale ON sale_items (sale_id);
CREATE INDEX idx_sales_created   ON sales (created_at);
